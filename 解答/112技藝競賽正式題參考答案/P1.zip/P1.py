from itertools import combinations


s = input()
print(max(j - i for i, j in combinations(range(len(s) + 1), 2) if len(set(s[i:j])) == j - i))
